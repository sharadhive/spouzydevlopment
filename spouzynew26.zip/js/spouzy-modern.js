/**
 * SPOUZY 2026 — Modern UI/UX Interactive Controller
 * Problem Solver Group (PSG) Specialist Wing
 */

// ---------------------------------------------------------------------------
// 0. FIRST-VISIT ANIMATED LOGO LOADER (Transparent, Non-blocking)
// ---------------------------------------------------------------------------
(function initFirstVisitLoader() {
  'use strict';

  // 1. Skip animation for reduced-motion users
  try {
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      return;
    }
  } catch (e) {}

  // 2. Show once per browser-tab session across any first page visited
  var SESSION_KEY = 'spouzy_loader_shown';
  try {
    if (sessionStorage.getItem(SESSION_KEY)) {
      return;
    }
    sessionStorage.setItem(SESSION_KEY, '1');
  } catch (e) {
    // If storage is disabled or unavailable, exit gracefully without blocking
    return;
  }

  // 3. Mount transparent loader overlay
  function mountLoader() {
    if (!document.body || document.getElementById('sp-first-visit-loader')) return;

    var overlay = document.createElement('div');
    overlay.id = 'sp-first-visit-loader';
    overlay.className = 'sp-first-visit-loader';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.setAttribute('role', 'presentation');

    var img = document.createElement('img');
    img.className = 'sp-first-visit-loader-img';
    img.alt = '';
    img.setAttribute('role', 'presentation');
    img.src = 'image/SPOUZY-loader.webp';

    var removed = false;
    function removeLoader() {
      if (removed) return;
      removed = true;
      overlay.classList.add('sp-loader-fade-out');
      setTimeout(function () {
        if (overlay && overlay.parentNode) {
          overlay.parentNode.removeChild(overlay);
        }
      }, 160);
    }

    // If image fails to load, remove immediately without delay
    img.onerror = function () {
      if (img.src.indexOf('.webp') !== -1) {
        // Fallback to GIF if WebP format is unsupported
        img.src = 'image/SPOUZY-loader.gif';
      } else {
        if (overlay && overlay.parentNode) {
          overlay.parentNode.removeChild(overlay);
        }
        removed = true;
      }
    };

    // Play once: the ribbon reveal animation is ~2.78-2.9s.
    // Start 150ms fade-out at ~2.65s so it finishes before the WebP/GIF loops.
    img.onload = function () {
      setTimeout(removeLoader, 2650);
    };

    // Fallback timer: ensure removal within 3.2s regardless of network or decode delays
    setTimeout(function () {
      if (!removed) removeLoader();
    }, 3200);

    overlay.appendChild(img);
    document.body.appendChild(overlay);
  }

  if (document.body) {
    mountLoader();
  } else {
    document.addEventListener('DOMContentLoaded', mountLoader);
  }
})();

document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  // -------------------------------------------------------------------------
  // 1. STICKY HEADER & SCROLL BEHAVIOR
  // -------------------------------------------------------------------------
  const header = document.querySelector('.sp-header-modern');
  if (header) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 30) {
        header.classList.add('sp-header-scrolled');
      } else {
        header.classList.remove('sp-header-scrolled');
      }
    }, { passive: true });
  }

  // -------------------------------------------------------------------------
  // 1B. NAVIGATION DROPDOWNS (MEGA-MENU & SIMPLE DROPDOWNS)
  // -------------------------------------------------------------------------
  const menus = Array.from(document.querySelectorAll('.guide-menu'));
  function toggleMenu(active) {
    menus.forEach(menu => {
      const open = menu === active;
      menu.querySelector('button').setAttribute('aria-expanded', String(open));
      menu.querySelector('.guide-links').hidden = !open;
      menu.classList.toggle('is-open', open);
      if (open) {
        const panel = menu.querySelector('.guide-links');
        panel.style.translate = '';
        const box = panel.getBoundingClientRect();
        const shift = Math.max(8 - box.left, Math.min(0, document.documentElement.clientWidth - 8 - box.right));
        panel.style.translate = shift + 'px 0';
      }
    });
  }
  menus.forEach(menu => {
    const button = menu.querySelector('button');
    const visuals = [...menu.querySelectorAll('.nav-visual')];
    const options = [...menu.querySelectorAll(".nav-options a, .nav-options .sp-submenu-trigger")];
    const policyTrigger = menu.querySelector('#sp-policy-trigger');
    const policySubmenu = menu.querySelector('#sp-policy-submenu');

    function closePolicySubmenu() {
      if (!policySubmenu) return;
      policySubmenu.hidden = true;
      policySubmenu.classList.remove('is-active');
      if (policyTrigger) {
        policyTrigger.setAttribute('aria-expanded', 'false');
        policyTrigger.removeAttribute('data-preview-active');
      }
    }

    function openPolicySubmenu() {
      if (!policySubmenu || !policyTrigger) return;
      options.forEach(item => item.removeAttribute('data-preview-active'));
      visuals.forEach(visual => visual.classList.remove('selected'));
      policyTrigger.setAttribute('aria-expanded', 'true');
      policyTrigger.setAttribute('data-preview-active', '');
      policySubmenu.hidden = false;
      policySubmenu.classList.add('is-active');
    }

    function showOption(index) {
      if (options[index] === policyTrigger) {
        openPolicySubmenu();
        return;
      }
      closePolicySubmenu();
      options.forEach((item, i) => item.toggleAttribute("data-preview-active", i === index));
      visuals.forEach((visual, i) => visual.classList.toggle('selected', i === index));
    }

    options.forEach((item, index) => {
      item.addEventListener('pointerenter', () => showOption(index));
      item.addEventListener('focus', () => showOption(index));
    });

    if (policyTrigger) {
      policyTrigger.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
        if (policySubmenu && !policySubmenu.hidden && policySubmenu.classList.contains('is-active')) {
          closePolicySubmenu();
          showOption(0);
        } else {
          openPolicySubmenu();
        }
      });
      policyTrigger.addEventListener('keydown', event => {
        if (event.key === 'ArrowRight' || event.key === ' ' || event.key === 'Enter') {
          event.preventDefault();
          openPolicySubmenu();
          const firstSublink = policySubmenu ? policySubmenu.querySelector('a') : null;
          if (firstSublink) firstSublink.focus();
        }
      });
    }

    if (policySubmenu) {
      policySubmenu.addEventListener('pointerenter', () => {
        openPolicySubmenu();
      });
      policySubmenu.addEventListener('keydown', event => {
        if (event.key === 'Escape' || event.key === 'ArrowLeft') {
          event.preventDefault();
          event.stopPropagation();
          closePolicySubmenu();
          if (policyTrigger) policyTrigger.focus();
        }
      });
    }

    button.addEventListener('pointerenter', () => showOption(0));
    button.addEventListener('focus', () => showOption(0));
    button.addEventListener('click', event => {
      const closing = event.detail === 0 && button.getAttribute('aria-expanded') === 'true';
      toggleMenu(closing ? null : menu);
      if (!closing) showOption(0);
    });
    menu.addEventListener('pointerenter', event => {
      if (event.pointerType === 'mouse' && !menu.matches(':focus-within')) {
        toggleMenu(menu);
      }
    });
    menu.addEventListener('pointerleave', () => {
      if (!menu.matches(':focus-within')) {
        closePolicySubmenu();
        toggleMenu(null);
      }
    });
    menu.addEventListener('keydown', event => {
      if (event.key === 'Escape') {
        if (policySubmenu && !policySubmenu.hidden && policySubmenu.contains(document.activeElement)) {
          event.preventDefault();
          closePolicySubmenu();
          if (policyTrigger) policyTrigger.focus();
          return;
        }
        closePolicySubmenu();
        button.focus();
        toggleMenu(null);
      }
      if (event.key === 'ArrowDown' && event.target === button) {
        event.preventDefault();
        toggleMenu(menu);
        const firstOpt = menu.querySelector('.nav-options a, .nav-options button');
        if (firstOpt) firstOpt.focus();
      }
    });
    menu.addEventListener('focusout', event => {
      if (!menu.contains(event.relatedTarget)) {
        closePolicySubmenu();
        toggleMenu(null);
      }
    });
  });
  document.addEventListener('click', event => {
    if (!event.target.closest('.guide-menu')) toggleMenu(null);
  });
  // 2. GRAND HERO LARGE-BANNER SLIDER WITH SYNCHRONIZED AUTO-TEXT
  // -------------------------------------------------------------------------
  const bannerSlides = document.querySelectorAll('.sp-hero-banner-slide');
  const bannerTabs = document.querySelectorAll('.sp-banner-tab-item');
  const bannerTimerFill = document.querySelector('.sp-banner-timer-fill');
  const bannerPrev = document.querySelector('.sp-banner-prev');
  const bannerNext = document.querySelector('.sp-banner-next');
  const bannerFrame = document.querySelector('.sp-hero-banner-frame');

  let currentBannerIdx = 0;
  const totalBanners = bannerSlides.length;
  const BANNER_DURATION = 5500; // 5.5 seconds per slide
  let bannerTimer = null;
  let bannerProgressInterval = null;
  let bannerProgressStart = 0;
  let isBannerHovered = false;

  function switchBanner(index) {
    if (!bannerSlides.length) return;
    currentBannerIdx = (index + totalBanners) % totalBanners;

    // Update Banner Slides (both background image and text on top transition together)
    bannerSlides.forEach((slide, i) => {
      if (i === currentBannerIdx) {
        slide.classList.add('is-active');
      } else {
        slide.classList.remove('is-active');
      }
    });

    // Update Bottom Tabs
    bannerTabs.forEach((tab, i) => {
      if (i === currentBannerIdx) {
        tab.classList.add('is-active');
        tab.setAttribute('aria-selected', 'true');
      } else {
        tab.classList.remove('is-active');
        tab.setAttribute('aria-selected', 'false');
      }
    });

    restartBannerTimer();
  }

  function restartBannerTimer() {
    clearInterval(bannerProgressInterval);
    clearTimeout(bannerTimer);

    if (bannerTimerFill) {
      bannerTimerFill.style.width = '0%';
    }

    if (isBannerHovered || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    bannerProgressStart = Date.now();
    bannerProgressInterval = setInterval(() => {
      if (isBannerHovered || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      const elapsed = Date.now() - bannerProgressStart;
      const pct = Math.min((elapsed / BANNER_DURATION) * 100, 100);
      if (bannerTimerFill) bannerTimerFill.style.width = pct + '%';
    }, 40);

    bannerTimer = setTimeout(() => {
      if (!isBannerHovered) {
        switchBanner(currentBannerIdx + 1);
      }
    }, BANNER_DURATION);
  }

  if (bannerSlides.length) {
    bannerTabs.forEach((tab, idx) => {
      tab.addEventListener('click', function () {
        switchBanner(idx);
      });
    });

    if (bannerPrev) {
      bannerPrev.addEventListener('click', function () {
        switchBanner(currentBannerIdx - 1);
      });
    }

    if (bannerNext) {
      bannerNext.addEventListener('click', function () {
        switchBanner(currentBannerIdx + 1);
      });
    }

    if (bannerFrame) {
      bannerFrame.addEventListener('mouseenter', function () {
        isBannerHovered = true;
      });
      bannerFrame.addEventListener('mouseleave', function () {
        isBannerHovered = false;
        restartBannerTimer();
      });
    }

    // Start with slide 0
    switchBanner(0);
  }

  // -------------------------------------------------------------------------
  // 3. HERO CARE MATCHER WIDGET INTERACTION
  // -------------------------------------------------------------------------
  const matcherBtn = document.querySelector('.sp-matcher-btn');
  const careSelect = document.querySelector('#sp-care-select');
  const formatSelect = document.querySelector('#sp-format-select');

  if (matcherBtn && careSelect) {
    matcherBtn.addEventListener('click', function (e) {
      e.preventDefault();
      const careVal = careSelect.value;
      const formatVal = formatSelect ? formatSelect.value : 'video';
      
      // Store in sessionStorage to pre-fill appointment page
      try {
        sessionStorage.setItem('spouzy_care_choice', careVal);
        sessionStorage.setItem('spouzy_format_choice', formatVal);
      } catch (err) {}

      // Smoothly navigate to book-appoinment.htm with parameters
      window.location.href = 'book-appoinment.htm?service=' + encodeURIComponent(careVal) + '&mode=' + encodeURIComponent(formatVal);
    });
  }

  // -------------------------------------------------------------------------
  // 4. INTERACTIVE 60-SEC RELATIONSHIP & CARE FINDER QUIZ
  // -------------------------------------------------------------------------
  const quizOptions = document.querySelectorAll('.sp-quiz-opt-btn');
  const quizResultBox = document.querySelector('.sp-quiz-result-box');
  const quizResultTitle = document.querySelector('#sp-quiz-res-title');
  const quizResultDesc = document.querySelector('#sp-quiz-res-desc');
  const quizResultLink = document.querySelector('#sp-quiz-res-link');

  const quizRecommendations = {
    'communication': {
      title: 'Recommended: Couples Communication & Conflict Resolution Therapy',
      desc: 'Our senior marital counsellors guide couples through structured exercises to de-escalate tension, restore emotional security, and build enduring understanding.',
      link: 'book-appoinment.htm?service=couples-therapy'
    },
    'premarital': {
      title: 'Recommended: Pre-Marital Alignment & Readiness Program',
      desc: 'Explore expectations, lifestyle habits, family integration, and financial harmony in a constructive, non-judgmental environment before making lifelong commitments.',
      link: 'book-appoinment.htm?service=premarital'
    },
    'intimacy': {
      title: 'Recommended: Confidential Intimacy & Medical Specialist Consultation',
      desc: 'Private, 1-on-1 or couples consultation with certified doctors and intimacy specialists adhering to strict clinical discretion and zero judgment.',
      link: 'book-appoinment.htm?service=intimacy-clinic'
    },
    'separation': {
      title: 'Recommended: Amicable Divorce & Dispute Mediation (PSG)',
      desc: 'Leverage Problem Solver Group’s 40-year multi-disciplinary dispute resolution expertise for respectful, amicable settlements prioritizing dignity and emotional wellbeing.',
      link: 'book-appoinment.htm?service=mediation'
    }
  };

  if (quizOptions.length && quizResultBox) {
    quizOptions.forEach(opt => {
      opt.addEventListener('click', function () {
        quizOptions.forEach(o => o.classList.remove('selected'));
        this.classList.add('selected');

        const key = this.getAttribute('data-concern');
        if (quizRecommendations[key]) {
          const rec = quizRecommendations[key];
          if (quizResultTitle) quizResultTitle.textContent = rec.title;
          if (quizResultDesc) quizResultDesc.textContent = rec.desc;
          if (quizResultLink) quizResultLink.href = rec.link;

          quizResultBox.style.display = 'flex';
          quizResultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      });
    });
  }

  // -------------------------------------------------------------------------
  // 5. SPOTLIGHT LIVE SEARCH MODAL
  // -------------------------------------------------------------------------
  const searchTriggers = document.querySelectorAll('.sp-search-trigger, .sp-search-btn');
  const searchModal = document.querySelector('.sp-search-modal');
  const searchField = document.querySelector('.sp-search-field');
  const searchClose = document.querySelector('.sp-search-close');
  const searchResults = document.querySelectorAll('.sp-search-result-item');

  function openSearch() {
    if (searchModal) {
      searchModal.classList.add('is-open');
      setTimeout(() => {
        if (searchField) searchField.focus();
      }, 100);
    }
  }

  function closeSearch() {
    if (searchModal) {
      searchModal.classList.remove('is-open');
      if (searchField) searchField.value = '';
      if (searchResults) {
        searchResults.forEach(item => item.style.display = 'block');
      }
    }
  }

  searchTriggers.forEach(trigger => {
    trigger.addEventListener('click', function (e) {
      e.preventDefault();
      openSearch();
    });
  });

  if (searchClose) {
    searchClose.addEventListener('click', closeSearch);
  }

  if (searchModal) {
    searchModal.addEventListener('click', function (e) {
      if (e.target === searchModal) {
        closeSearch();
      }
    });
  }

  // Keyboard shortcut Ctrl+K or / to open search
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      if (searchModal && searchModal.classList.contains('is-open')) {
        closeSearch();
      } else {
        openSearch();
      }
    } else if (e.key === 'Escape' && searchModal && searchModal.classList.contains('is-open')) {
      closeSearch();
    }
  });

  // Live filter results
  if (searchField && searchResults.length) {
    searchField.addEventListener('input', function () {
      const q = this.value.trim().toLowerCase();
      searchResults.forEach(item => {
        const text = item.textContent.toLowerCase();
        if (text.includes(q)) {
          item.style.display = 'block';
        } else {
          item.style.display = 'none';
        }
      });
    });
  }

  // -------------------------------------------------------------------------
  // 6. MOBILE DRAWER NAVIGATION
  // -------------------------------------------------------------------------
  const mobileToggle = document.querySelector('.sp-mobile-toggle');
  const mobileDrawer = document.querySelector('.sp-mobile-drawer');
  const mobileClose = document.querySelector('.sp-mobile-drawer-close');

  if (mobileToggle && mobileDrawer) {
    mobileToggle.addEventListener('click', function () {
      mobileDrawer.classList.toggle('is-open');
      document.body.style.overflow = mobileDrawer.classList.contains('is-open') ? 'hidden' : '';
    });

    if (mobileClose) {
      mobileClose.addEventListener('click', function () {
        mobileDrawer.classList.remove('is-open');
        document.body.style.overflow = '';
      });
    }

    mobileDrawer.addEventListener('click', function (e) {
      if (e.target === mobileDrawer) {
        mobileDrawer.classList.remove('is-open');
        document.body.style.overflow = '';
      }
    });
  }

  // -------------------------------------------------------------------------
  // 7. SMOOTH IN-PAGE ANCHOR JUMPS
  // -------------------------------------------------------------------------
  document.querySelectorAll('a[href^="#"]:not([href="#"])').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // -------------------------------------------------------------------------
  // 8. SCROLL-TRIGGERED REVEAL ANIMATION ENGINE
  // -------------------------------------------------------------------------
  const revealElements = document.querySelectorAll('.sp-reveal, .sp-reveal-left, .sp-reveal-right, .sp-reveal-scale');
  if ('IntersectionObserver' in window && revealElements.length) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('sp-in-view');
          observer.unobserve(entry.target);
        }
      });
    }, {
      root: null,
      threshold: 0.12,
      rootMargin: '0px 0px -40px 0px'
    });

    revealElements.forEach(el => revealObserver.observe(el));
  } else {
    // Fallback if IntersectionObserver not supported
    revealElements.forEach(el => el.classList.add('sp-in-view'));
  }

  // -------------------------------------------------------------------------
  // 9. DYNAMIC NUMBER COUNT-UP ANIMATION
  // -------------------------------------------------------------------------
  const counters = document.querySelectorAll('.sp-count-up');
  if ('IntersectionObserver' in window && counters.length) {
    const counterObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const targetNum = parseInt(el.getAttribute('data-target'), 10) || 0;
          const suffix = el.getAttribute('data-suffix') || '';
          const prefix = el.getAttribute('data-prefix') || '';
          const duration = 2000; // 2 seconds
          const startTime = performance.now();

          function updateCounter(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            // Ease-out cubic
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const currentVal = Math.floor(easeOut * targetNum);

            el.textContent = prefix + currentVal.toLocaleString() + suffix;

            if (progress < 1) {
              requestAnimationFrame(updateCounter);
            } else {
              el.textContent = prefix + targetNum.toLocaleString() + suffix;
              el.classList.add('is-counted');
            }
          }

          requestAnimationFrame(updateCounter);
          observer.unobserve(el);
        }
      });
    }, {
      threshold: 0.3
    });

    counters.forEach(c => counterObserver.observe(c));
  }

  // -------------------------------------------------------------------------
  // 10. ROTATING KINETIC WORD ANIMATION
  // -------------------------------------------------------------------------
  const rotatingWords = document.querySelectorAll('.sp-rotating-word');
  if (rotatingWords.length > 1) {
    let activeWordIdx = 0;
    setInterval(() => {
      rotatingWords[activeWordIdx].classList.remove('is-active');
      rotatingWords[activeWordIdx].classList.add('is-exit');

      const prevIdx = activeWordIdx;
      setTimeout(() => {
        rotatingWords[prevIdx].classList.remove('is-exit');
      }, 600);

      activeWordIdx = (activeWordIdx + 1) % rotatingWords.length;
      rotatingWords[activeWordIdx].classList.add('is-active');
    }, 2800);
  }

  // -------------------------------------------------------------------------
  // 11. SUBPAGE INTERACTIVE CONTROLLERS (BOOKING, SLOTS, FILTERS, FEEDBACK)
  // -------------------------------------------------------------------------

  // A. Time Slot Selector
  document.querySelectorAll('.sp-slot-pill').forEach(pill => {
    pill.addEventListener('click', function () {
      const parent = this.closest('.sp-slots-grid');
      if (parent) {
        parent.querySelectorAll('.sp-slot-pill').forEach(p => p.classList.remove('is-selected'));
      }
      this.classList.add('is-selected');
      const hiddenInput = document.getElementById('selectedTimeSlot');
      if (hiddenInput) {
        hiddenInput.value = this.textContent.trim();
      }
    });
  });

  // B. Doctor "Quick Book" click: Auto-select doctor in form & scroll smoothly
  document.querySelectorAll('[data-book-doctor]').forEach(btn => {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      const doctorName = this.getAttribute('data-book-doctor');
      const doctorSelect = document.getElementById('spDoctorSelect');
      if (doctorSelect) {
        for (let i = 0; i < doctorSelect.options.length; i++) {
          if (doctorSelect.options[i].text.includes(doctorName) || doctorSelect.options[i].value.includes(doctorName)) {
            doctorSelect.selectedIndex = i;
            break;
          }
        }
      }
      const bookingCard = document.querySelector('.sp-booking-card-modern');
      if (bookingCard) {
        bookingCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        bookingCard.style.boxShadow = '0 0 0 4px rgba(191, 103, 79, 0.4)';
        setTimeout(() => {
          bookingCard.style.boxShadow = '';
        }, 1200);
      }
    });
  });

  // C. Specialty Filter in Doctor Directory
  document.querySelectorAll('.sp-filter-pill').forEach(pill => {
    pill.addEventListener('click', function () {
      const parent = this.closest('.sp-filter-bar');
      if (parent) {
        parent.querySelectorAll('.sp-filter-pill').forEach(p => p.classList.remove('is-active'));
      }
      this.classList.add('is-active');
      const filter = this.getAttribute('data-filter');
      const doctorCards = document.querySelectorAll('.sp-doctor-card-modern');
      doctorCards.forEach(card => {
        if (!filter || filter === 'all') {
          card.style.display = 'grid';
        } else {
          const category = card.getAttribute('data-category') || '';
          if (category.toLowerCase().includes(filter.toLowerCase())) {
            card.style.display = 'grid';
          } else {
            card.style.display = 'none';
          }
        }
      });
    });
  });

  // D. Mode Tabs (All Modes, Virtual, Clinic)
  document.querySelectorAll('.sp-mode-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const parent = this.closest('.sp-booking-modes');
      if (parent) {
        parent.querySelectorAll('.sp-mode-btn').forEach(b => b.classList.remove('is-active'));
      }
      this.classList.add('is-active');
      const mode = this.getAttribute('data-mode');
      const doctorCards = document.querySelectorAll('.sp-doctor-card-modern');
      doctorCards.forEach(card => {
        if (!mode || mode === 'all') {
          card.style.display = 'grid';
        } else {
          const cardModes = card.getAttribute('data-modes') || '';
          if (cardModes.toLowerCase().includes(mode.toLowerCase())) {
            card.style.display = 'grid';
          } else {
            card.style.display = 'none';
          }
        }
      });
    });
  });

  // E. Confidential Booking & Contact Form Submission Feedback
  const bookingForm = document.getElementById('spBookingForm');
  if (bookingForm) {
    const bookingDateInput = document.getElementById('spBookingDate');
    if (bookingDateInput) {
      // Dedicated Appointment Scheduler Controller for book-appoinment.htm
      initSpouzyScheduler(bookingForm);
    } else {
      // Legacy doctor directory quick booking on appointment.htm
      bookingForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const submitBtn = this.querySelector('button[type="submit"]');
        const origText = submitBtn ? submitBtn.innerHTML : 'Submit';
        if (submitBtn) {
          submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Confirming Discretion...';
          submitBtn.disabled = true;
        }
        setTimeout(() => {
          alert('Preview only. Your details stayed in this browser.');
          bookingForm.reset();
          if (submitBtn) {
            submitBtn.innerHTML = origText;
            submitBtn.disabled = false;
          }
        }, 900);
      });
    }
  }

  // -------------------------------------------------------------------------
  // 12. DEDICATED APPOINTMENT SCHEDULER CONTROLLER (ASIA/KOLKATA IST)
  // -------------------------------------------------------------------------
  function initSpouzyScheduler(form) {
    // A. Centralized Sample Weekly Schedule Configuration
    const SPOUZY_SCHEDULE_CONFIG = {
      timezone: 'Asia/Kolkata',
      // Weekly operating hours (24-hour format in IST)
      weeklyHours: {
        0: { open: '10:00', close: '14:00', mode: 'virtual' }, // Sunday: Virtual Telehealth Only (10:00 AM - 02:00 PM)
        1: { open: '10:00', close: '19:00' }, // Monday
        2: { open: '10:00', close: '19:00' }, // Tuesday
        3: { open: '10:00', close: '19:00' }, // Wednesday
        4: { open: '10:00', close: '19:00' }, // Thursday
        5: { open: '10:00', close: '19:00' }, // Friday
        6: { open: '10:00', close: '18:00' }  // Saturday
      },
      // Daily clinical lunch break & intermission
      breakHours: [
        { start: '13:00', end: '14:00', reason: 'Intermission' }
      ],
      // Sample Booked 30-minute intervals by day of week (0-6)
      // Format: 'HH:MM-HH:MM'
      sampleBookedSlotsByDay: {
        1: ['10:30-11:00', '15:00-15:30', '15:30-16:00'], // Monday: 10:30-11:00 booked (proves 10:00-10:30 free for 30m, but 10:00-11:00 disabled for 1h!)
        2: ['11:30-12:00', '16:00-16:30'],
        3: ['10:30-11:00', '14:30-15:00'],
        4: ['12:00-12:30', '16:30-17:00'],
        5: ['10:30-11:00', '17:00-17:30'],
        6: ['11:00-11:30', '15:30-16:00'],
        0: ['11:30-12:00']
      },
      sampleBookedDates: {}
    };

    // B. Form & Control References
    const dateInput = document.getElementById('spBookingDate');
    const formattedDateText = document.getElementById('spFormattedDateText');
    const durationInput = document.getElementById('spBookingDuration');
    const durationBtns = document.querySelectorAll('.sp-duration-btn');
    const timePickerTrigger = document.getElementById('spTimePickerTrigger');
    const timeDisplayVal = document.getElementById('spTimeDisplayVal');
    const timePickerPopover = document.getElementById('spTimePickerPopover');
    const popoverDateText = document.getElementById('spPopoverDateText');
    const popoverDurationBadge = document.getElementById('spPopoverDurationBadge');
    const closePopoverBtn = document.getElementById('spClosePopoverBtn');
    const pickerBackdrop = document.getElementById('spPickerBackdrop');
    const slotsContainer = document.getElementById('spSlotsContainer');
    const slotNotice = document.getElementById('spSlotNotice');
    const selectedSlotInput = document.getElementById('spSelectedTimeSlot');
    const serviceSelect = document.getElementById('spServiceSelect');
    const consultModeSelect = document.getElementById('spConsultMode');
    const summaryBox = document.getElementById('spAppointmentSummaryBox');
    const summaryContent = document.getElementById('spSummaryContent');
    const summarySubContent = document.getElementById('spSummarySubContent');
    const validationError = document.getElementById('spBookingValidationError');
    const submitBtn = document.getElementById('spBookingSubmitBtn');
    const successCard = document.getElementById('spBookingSuccessCard');

    // C. Timezone & Date Formatting Utilities
    function getNowIST() {
      const now = new Date();
      const istString = now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
      return new Date(istString);
    }

    function getISTDateString(d = getNowIST()) {
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return y + '-' + m + '-' + day;
    }

    function formatFullDateIST(dateStr) {
      if (!dateStr) return '';
      const parts = dateStr.split('-');
      if (parts.length !== 3) return '';
      const y = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10);
      const d = parseInt(parts[2], 10);
      const dt = new Date(y, m - 1, d);
      const weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      return weekdays[dt.getDay()] + ', ' + d + ' ' + months[m - 1] + ' ' + y;
    }

    function parseTimeToMinutes(t) {
      const [h, m] = t.split(':').map(Number);
      return h * 60 + m;
    }

    function formatMinutesTo12h(mins) {
      let h = Math.floor(mins / 60);
      const m = mins % 60;
      const ampm = h >= 12 ? 'PM' : 'AM';
      h = h % 12;
      if (h === 0) h = 12;
      return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ' ' + ampm;
    }

    // D. Preselect Guidance Area & Consultation Mode from URL or sessionStorage
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const serviceParam = urlParams.get('service') || sessionStorage.getItem('spouzy_care_choice');
      const modeParam = urlParams.get('mode') || sessionStorage.getItem('spouzy_format_choice');

      if (serviceParam && serviceSelect) {
        const sLower = serviceParam.toLowerCase();
        for (let i = 0; i < serviceSelect.options.length; i++) {
          const optVal = serviceSelect.options[i].value.toLowerCase();
          if (sLower.includes(optVal) || optVal.includes(sLower) ||
             (sLower.includes('marital') && optVal.includes('couples')) ||
             (sLower.includes('divorce') && optVal.includes('mediation')) ||
             (sLower.includes('sex') && optVal.includes('intimacy'))) {
            serviceSelect.selectedIndex = i;
            break;
          }
        }
      }

      if (modeParam && consultModeSelect) {
        const mLower = modeParam.toLowerCase();
        for (let i = 0; i < consultModeSelect.options.length; i++) {
          const optVal = consultModeSelect.options[i].value.toLowerCase();
          if (mLower.includes(optVal) || optVal.includes(mLower) ||
             (mLower.includes('tele') && optVal === 'virtual') ||
             (mLower.includes('video') && optVal === 'virtual') ||
             (mLower.includes('inperson') && optVal === 'mumbai')) {
            consultModeSelect.selectedIndex = i;
            break;
          }
        }
      }
    } catch (e) {}

    // E. Initialize Minimum Date & Initial Date Selection (Asia/Kolkata)
    const todayISTString = getISTDateString();
    if (dateInput) {
      dateInput.min = todayISTString;

      // Determine smart initial date: if today's hours have passed, default to tomorrow
      if (!dateInput.value) {
        const nowIST = getNowIST();
        const currentMins = nowIST.getHours() * 60 + nowIST.getMinutes();
        const todayDayOfWeek = nowIST.getDay();
        const todayHours = SPOUZY_SCHEDULE_CONFIG.weeklyHours[todayDayOfWeek];
        const todayCloseMins = todayHours ? parseTimeToMinutes(todayHours.close) : 0;

        if (currentMins >= todayCloseMins - 60) {
          const tmrw = getNowIST();
          tmrw.setDate(tmrw.getDate() + 1);
          dateInput.value = getISTDateString(tmrw);
        } else {
          dateInput.value = todayISTString;
        }
      }

      if (formattedDateText) {
        formattedDateText.textContent = formatFullDateIST(dateInput.value);
      }
    }

    // F. Slot Availability Calculation Engine
    function calculateSlots(dateStr, durationMinutes, mode) {
      const parts = dateStr.split('-');
      if (parts.length !== 3) return { error: 'Invalid date format', slots: [] };
      const y = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10);
      const d = parseInt(parts[2], 10);
      const dateObj = new Date(y, m - 1, d);
      const dayOfWeek = dateObj.getDay();

      const dayConfig = SPOUZY_SCHEDULE_CONFIG.weeklyHours[dayOfWeek];
      if (!dayConfig) {
        return { notice: 'PSG Centers are closed on this date. Please choose another date.', slots: [] };
      }

      // In-person clinic Sunday closure check
      if (dayOfWeek === 0 && mode && mode !== 'virtual') {
        return {
          notice: 'In-person clinic centers are closed on Sundays. Please choose a weekday or switch Consultation Mode to Virtual Telehealth.',
          slots: []
        };
      }

      const openMins = parseTimeToMinutes(dayConfig.open);
      const closeMins = parseTimeToMinutes(dayConfig.close);
      const breakStart = parseTimeToMinutes(SPOUZY_SCHEDULE_CONFIG.breakHours[0].start);
      const breakEnd = parseTimeToMinutes(SPOUZY_SCHEDULE_CONFIG.breakHours[0].end);

      const bookedList = (SPOUZY_SCHEDULE_CONFIG.sampleBookedSlotsByDay[dayOfWeek] || []).concat(
        SPOUZY_SCHEDULE_CONFIG.sampleBookedDates[dateStr] || []
      );

      const nowIST = getNowIST();
      const isDateToday = (dateStr === todayISTString);
      const currentISTMinutes = nowIST.getHours() * 60 + nowIST.getMinutes();

      const slots = [];
      const step = durationMinutes === 30 ? 30 : 60;

      for (let startMins = openMins; startMins + durationMinutes <= closeMins; startMins += step) {
        const endMins = startMins + durationMinutes;

        // Check break overlap (e.g. 13:00 to 14:00)
        let isIntermission = false;
        if (startMins < breakEnd && endMins > breakStart) {
          isIntermission = true;
        }

        // Check if any 30-min block within the requested window is booked
        let isBooked = false;
        for (let sub = startMins; sub < endMins; sub += 30) {
          const subStartStr = String(Math.floor(sub / 60)).padStart(2, '0') + ':' + String(sub % 60).padStart(2, '0');
          const subEndMins = sub + 30;
          const subEndStr = String(Math.floor(subEndMins / 60)).padStart(2, '0') + ':' + String(subEndMins % 60).padStart(2, '0');
          const intervalKey = subStartStr + '-' + subEndStr;

          if (bookedList.includes(intervalKey)) {
            isBooked = true;
            break;
          }
        }

        // Check elapsed if today in IST
        let isElapsed = false;
        if (isDateToday && startMins <= currentISTMinutes) {
          isElapsed = true;
        }

        const label = formatMinutesTo12h(startMins) + ' – ' + formatMinutesTo12h(endMins);
        let status = 'available';
        let reason = '';

        if (isElapsed) {
          status = 'disabled';
          reason = 'Passed';
        } else if (isIntermission) {
          status = 'disabled';
          reason = 'Intermission';
        } else if (isBooked) {
          status = 'disabled';
          reason = 'Booked';
        }

        slots.push({
          startMins,
          endMins,
          label,
          status,
          reason,
          duration: durationMinutes
        });
      }

      return { slots };
    }

    // G. Time Picker Popover Open / Close / Header State
    function isPopoverOpen() {
      return timePickerPopover && timePickerPopover.style.display === 'block';
    }

    function updatePopoverHeader() {
      if (popoverDateText) {
        popoverDateText.textContent = (dateInput && dateInput.value) ? formatFullDateIST(dateInput.value) : 'Select date first';
      }
      if (popoverDurationBadge) {
        const dVal = durationInput ? durationInput.value : '30';
        popoverDurationBadge.innerHTML = '<i class="fa fa-hourglass-half"></i> ' + (dVal === '60' ? '1 hour' : '30 minutes');
      }
    }

    function openTimePicker() {
      if (!dateInput || !dateInput.value) {
        if (dateInput) {
          dateInput.focus();
          if (typeof dateInput.showPicker === 'function') {
            try { dateInput.showPicker(); } catch (e) {}
          }
        }
        showError('Please choose an appointment date first.');
        return;
      }

      updatePopoverHeader();
      renderSlots();

      if (timePickerPopover) {
        timePickerPopover.style.display = 'block';
      }
      if (pickerBackdrop) {
        if (window.innerWidth <= 640) {
          pickerBackdrop.style.display = 'block';
        } else {
          pickerBackdrop.style.display = 'none';
        }
      }
      if (timePickerTrigger) {
        timePickerTrigger.classList.add('is-active');
        timePickerTrigger.setAttribute('aria-expanded', 'true');
      }

      // Accessibility: move focus inside popover
      setTimeout(() => {
        if (slotsContainer) {
          const selectedBtn = slotsContainer.querySelector('.sp-slot-range-btn.is-selected');
          if (selectedBtn) {
            selectedBtn.focus();
            return;
          }
          const firstAvailable = slotsContainer.querySelector('.sp-slot-range-btn:not(:disabled)');
          if (firstAvailable) {
            firstAvailable.focus();
            return;
          }
        }
        if (closePopoverBtn) {
          closePopoverBtn.focus();
        }
      }, 50);
    }

    function closeTimePicker() {
      if (timePickerPopover) {
        timePickerPopover.style.display = 'none';
      }
      if (pickerBackdrop) {
        pickerBackdrop.style.display = 'none';
      }
      if (timePickerTrigger) {
        timePickerTrigger.classList.remove('is-active');
        timePickerTrigger.setAttribute('aria-expanded', 'false');
      }
    }

    function updateTimeFieldState() {
      if (!timePickerTrigger || !timeDisplayVal) return;
      if (!dateInput || !dateInput.value) {
        timePickerTrigger.disabled = true;
        timePickerTrigger.classList.add('is-disabled');
        timePickerTrigger.classList.remove('has-value');
        timeDisplayVal.textContent = 'Choose an appointment date first';
      } else {
        timePickerTrigger.disabled = false;
        timePickerTrigger.classList.remove('is-disabled');
        if (selectedSlotInput && selectedSlotInput.value) {
          timeDisplayVal.textContent = selectedSlotInput.value;
          timePickerTrigger.classList.add('has-value');
        } else {
          timeDisplayVal.textContent = 'Select appointment time';
          timePickerTrigger.classList.remove('has-value');
        }
      }
    }

    // H. Render Slots into Popover
    function renderSlots() {
      if (!slotsContainer || !dateInput) return;

      try {
        const dateVal = dateInput.value;
        const durationVal = parseInt(durationInput ? durationInput.value : '30', 10) || 30;
        const modeVal = consultModeSelect ? consultModeSelect.value : 'virtual';

        if (!dateVal) {
          slotsContainer.innerHTML = '';
          if (slotNotice) {
            slotNotice.innerHTML = '<i class="fa fa-info-circle"></i> Please choose an appointment date first.';
            slotNotice.style.display = 'block';
          }
          return;
        }

        if (dateVal < todayISTString) {
          slotsContainer.innerHTML = '';
          if (slotNotice) {
            slotNotice.innerHTML = '<i class="fa fa-exclamation-triangle"></i> Past dates cannot be selected. Please choose today or a future date.';
            slotNotice.style.display = 'block';
          }
          return;
        }

        const result = calculateSlots(dateVal, durationVal, modeVal);

        if (result.notice) {
          slotsContainer.innerHTML = '';
          if (slotNotice) {
            slotNotice.innerHTML = '<i class="fa fa-info-circle"></i> ' + result.notice;
            slotNotice.style.display = 'block';
          }
          updateSummary();
          return;
        }

        const slots = result.slots || [];
        let availableCount = 0;
        slotsContainer.innerHTML = '';

        slots.forEach(slot => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'sp-slot-range-btn';
          btn.setAttribute('data-slot', slot.label);

          if (slot.status === 'disabled') {
            btn.classList.add('is-disabled');
            btn.disabled = true;
            btn.setAttribute('aria-disabled', 'true');
            btn.innerHTML = '<span class="sp-slot-time">' + slot.label + '</span>' +
                            '<span class="sp-slot-badge">' + (slot.reason || 'Unavailable') + '</span>';
          } else {
            availableCount++;
            btn.innerHTML = '<span class="sp-slot-time">' + slot.label + '</span>';
            
            // Check if this slot is currently selected
            if (selectedSlotInput && selectedSlotInput.value === slot.label) {
              btn.classList.add('is-selected');
            }

            btn.addEventListener('click', function () {
              const chosenSlot = slot.label;
              if (selectedSlotInput) {
                selectedSlotInput.value = chosenSlot;
              }
              if (timeDisplayVal) {
                timeDisplayVal.textContent = chosenSlot;
              }
              if (timePickerTrigger) {
                timePickerTrigger.classList.add('has-value');
                closeTimePicker();
                timePickerTrigger.focus(); // Return focus to the time field!
              }
              if (validationError) {
                validationError.style.display = 'none';
              }
              updateSummary();
            });
          }

          slotsContainer.appendChild(btn);
        });

        if (availableCount === 0) {
          if (slotNotice) {
            slotNotice.innerHTML = 
              '<div style="text-align: center; padding: 12px 6px;">' +
                '<i class="fa fa-calendar-times-o" style="font-size: 20px; color: var(--sp-copper); margin-bottom: 6px; display: block;"></i>' +
                '<strong>No available times for this date and duration.</strong><br>' +
                '<small style="color: var(--sp-text-muted);">Please choose another date on the calendar.</small><br>' +
                '<button type="button" class="sp-choose-date-btn" id="spPickerChangeDateBtn"><i class="fa fa-calendar"></i> Choose Another Date</button>' +
              '</div>';
            slotNotice.style.display = 'block';

            const changeDateBtn = document.getElementById('spPickerChangeDateBtn');
            if (changeDateBtn) {
              changeDateBtn.addEventListener('click', function () {
                closeTimePicker();
                if (dateInput) {
                  dateInput.focus();
                  if (typeof dateInput.showPicker === 'function') {
                    try { dateInput.showPicker(); } catch (e) {}
                  }
                }
              });
            }
          }
        } else {
          if (slotNotice) {
            slotNotice.style.display = 'none';
          }
        }

        updateSummary();
      } catch (err) {
        console.error('Error rendering slots:', err);
        slotsContainer.innerHTML = '';
        if (slotNotice) {
          slotNotice.innerHTML = '<i class="fa fa-exclamation-triangle"></i> Unable to load availability. <button type="button" class="sp-retry-btn" id="spRetrySlotsBtn">Retry</button>';
          slotNotice.style.display = 'block';
          const retryBtn = document.getElementById('spRetrySlotsBtn');
          if (retryBtn) {
            retryBtn.addEventListener('click', renderSlots);
          }
        }
      }
    }

    // I. Update Compact Appointment Summary Box
    function updateSummary() {
      if (!summaryContent) return;

      const dateVal = dateInput ? dateInput.value : '';
      const durationVal = durationInput ? durationInput.value : '30';
      const slotVal = selectedSlotInput ? selectedSlotInput.value : '';
      const durationText = durationVal === '60' ? '1 hour' : '30 minutes';

      const serviceText = serviceSelect && serviceSelect.selectedIndex >= 0 ? 
        serviceSelect.options[serviceSelect.selectedIndex].text.split('(')[0].trim() : 'Guidance Consultation';
      const modeText = consultModeSelect && consultModeSelect.selectedIndex >= 0 ? 
        consultModeSelect.options[consultModeSelect.selectedIndex].text.split('(')[0].trim() : 'Encrypted Telehealth';

      if (dateVal && slotVal) {
        const fullDate = formatFullDateIST(dateVal);
        summaryContent.className = 'sp-summary-text is-ready';
        summaryContent.innerHTML = 
          '<span class="sp-summary-highlight"><i class="fa fa-calendar-check-o"></i> ' + fullDate + '</span>' +
          '<span class="sp-summary-dot">·</span>' +
          '<span class="sp-summary-highlight"><i class="fa fa-clock-o"></i> ' + slotVal + ' IST</span>' +
          '<span class="sp-summary-dot">·</span>' +
          '<span class="sp-summary-highlight"><i class="fa fa-hourglass-half"></i> ' + durationText + '</span>';
        
        if (summarySubContent) {
          summarySubContent.style.display = 'block';
          summarySubContent.innerHTML = '<strong>' + serviceText + '</strong> · ' + modeText;
        }
      } else {
        summaryContent.className = 'sp-summary-text is-placeholder';
        if (dateVal) {
          summaryContent.textContent = 'Date: ' + formatFullDateIST(dateVal) + ' (' + durationText + '). Please choose an available appointment time above.';
        } else {
          summaryContent.textContent = 'Please choose an appointment date, duration, and appointment time above.';
        }
        if (summarySubContent) {
          summarySubContent.style.display = 'none';
        }
      }
    }

    function showError(msg) {
      if (validationError) {
        validationError.innerHTML = '<i class="fa fa-exclamation-circle"></i> ' + msg;
        validationError.style.display = 'block';
        validationError.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        alert(msg);
      }
    }

    // J. Event Listeners for Opening/Closing & Changes
    if (timePickerTrigger) {
      timePickerTrigger.addEventListener('click', function (e) {
        e.preventDefault();
        if (this.disabled) return;
        if (isPopoverOpen()) {
          closeTimePicker();
        } else {
          openTimePicker();
        }
      });

      timePickerTrigger.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
          e.preventDefault();
          if (!this.disabled) {
            openTimePicker();
          }
        }
      });
    }

    if (closePopoverBtn) {
      closePopoverBtn.addEventListener('click', function (e) {
        e.preventDefault();
        closeTimePicker();
        if (timePickerTrigger) timePickerTrigger.focus();
      });
    }

    if (pickerBackdrop) {
      pickerBackdrop.addEventListener('click', function () {
        closeTimePicker();
        if (timePickerTrigger) timePickerTrigger.focus();
      });
    }

    // Escape closes popover & returns focus
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && isPopoverOpen()) {
        e.preventDefault();
        closeTimePicker();
        if (timePickerTrigger) timePickerTrigger.focus();
      }
    });

    // Outside click closes popover on desktop
    document.addEventListener('click', function (e) {
      if (isPopoverOpen()) {
        if (timePickerPopover && !timePickerPopover.contains(e.target) &&
            timePickerTrigger && !timePickerTrigger.contains(e.target)) {
          closeTimePicker();
        }
      }
    });

    if (dateInput) {
      dateInput.addEventListener('change', function () {
        if (formattedDateText) {
          formattedDateText.textContent = formatFullDateIST(this.value) || 'Select date';
        }
        if (selectedSlotInput) {
          selectedSlotInput.value = '';
        }
        closeTimePicker();
        updateTimeFieldState();
        updatePopoverHeader();
        renderSlots();
        updateSummary();
      });
    }

    if (durationBtns.length) {
      durationBtns.forEach(btn => {
        btn.addEventListener('click', function () {
          durationBtns.forEach(b => {
            b.classList.remove('is-active');
            b.setAttribute('aria-checked', 'false');
          });
          this.classList.add('is-active');
          this.setAttribute('aria-checked', 'true');

          const chosenDuration = this.getAttribute('data-duration') || '30';
          if (durationInput) {
            durationInput.value = chosenDuration;
          }
          if (selectedSlotInput) {
            selectedSlotInput.value = '';
          }
          closeTimePicker();
          updateTimeFieldState();
          updatePopoverHeader();
          renderSlots();
          updateSummary();
        });
      });
    }

    if (serviceSelect) {
      serviceSelect.addEventListener('change', function () {
        if (selectedSlotInput) {
          selectedSlotInput.value = '';
        }
        closeTimePicker();
        updateTimeFieldState();
        renderSlots();
        updateSummary();
      });
    }

    if (consultModeSelect) {
      consultModeSelect.addEventListener('change', function () {
        if (selectedSlotInput) {
          selectedSlotInput.value = '';
        }
        closeTimePicker();
        updateTimeFieldState();
        renderSlots();
        updateSummary();
      });
    }

    // K. Form Submission Handler
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      if (validationError) {
        validationError.style.display = 'none';
      }

      const dateVal = dateInput ? dateInput.value : '';
      const slotVal = selectedSlotInput ? selectedSlotInput.value : '';
      const durationVal = durationInput ? durationInput.value : '30';
      const durationText = durationVal === '60' ? '1 hour' : '30 minutes';

      const patientNameInput = document.getElementById('spPatientName');
      const patientPhoneInput = document.getElementById('spPatientPhone');
      const patientEmailInput = document.getElementById('spPatientEmail');

      const patientName = patientNameInput ? patientNameInput.value.trim() : '';
      const patientPhone = patientPhoneInput ? patientPhoneInput.value.trim() : '';
      const patientEmail = patientEmailInput ? patientEmailInput.value.trim() : '';

      // Validate inputs
      if (!dateVal) {
        showError('Please choose an appointment date.');
        if (dateInput) dateInput.focus();
        return;
      }

      if (dateVal < todayISTString) {
        showError('Past dates cannot be selected. Please choose today or a future date.');
        if (dateInput) dateInput.focus();
        return;
      }

      if (!slotVal) {
        showError('Please select an appointment time.');
        if (timePickerTrigger) {
          timePickerTrigger.focus();
          timePickerTrigger.style.borderColor = '#bf674f';
          timePickerTrigger.style.boxShadow = '0 0 0 4px rgba(191, 103, 79, 0.3)';
          setTimeout(() => {
            timePickerTrigger.style.borderColor = '';
            timePickerTrigger.style.boxShadow = '';
          }, 1500);
          openTimePicker();
        }
        return;
      }

      if (!patientName) {
        showError('Please provide your name or discreet alias.');
        if (patientNameInput) patientNameInput.focus();
        return;
      }

      if (!patientPhone) {
        showError('Please provide your mobile / WhatsApp number for confidential confirmation.');
        if (patientPhoneInput) patientPhoneInput.focus();
        return;
      }

      if (!patientEmail || !patientEmail.includes('@')) {
        showError('Please provide a valid confidential email ID.');
        if (patientEmailInput) patientEmailInput.focus();
        return;
      }

      // Simulate secure encryption & request confirmation
      const origText = submitBtn ? submitBtn.innerHTML : 'Request This Time';
      if (submitBtn) {
        submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Encrypting &amp; Confirming...';
        submitBtn.disabled = true;
      }

      setTimeout(() => {
        if (submitBtn) {
          submitBtn.innerHTML = origText;
          submitBtn.disabled = false;
        }

        const fullDate = formatFullDateIST(dateVal);
        const serviceText = serviceSelect ? serviceSelect.options[serviceSelect.selectedIndex].text : '';
        const modeText = consultModeSelect ? consultModeSelect.options[consultModeSelect.selectedIndex].text : '';

        if (successCard) {
          successCard.innerHTML = 
            '<div class="sp-success-header">' +
              '<div class="sp-success-icon"><i class="fa fa-check"></i></div>' +
              '<div>' +
                '<div class="sp-success-badge">Request Received · Subject to Confirmation</div>' +
                '<h3 class="sp-success-title">Appointment Request Submitted</h3>' +
              '</div>' +
            '</div>' +
            '<div class="sp-success-grid">' +
              '<div class="sp-success-item"><strong>Requested Date</strong><span>' + fullDate + '</span></div>' +
              '<div class="sp-success-item"><strong>Time Window</strong><span>' + slotVal + ' IST (' + durationText + ')</span></div>' +
              '<div class="sp-success-item"><strong>Guidance Area</strong><span>' + serviceText + '</span></div>' +
              '<div class="sp-success-item"><strong>Consultation Mode</strong><span>' + modeText + '</span></div>' +
              '<div class="sp-success-item"><strong>Patient / Alias</strong><span>' + patientName + '</span></div>' +
              '<div class="sp-success-item"><strong>Confidential Mobile</strong><span>' + patientPhone + '</span></div>' +
            '</div>' +
            '<p class="sp-success-notice">' +
              '<i class="fa fa-shield"></i> <strong>PSG Strict Discretion Guarantee:</strong> Our clinical care coordinator will review availability and dispatch encrypted session credentials to your WhatsApp (' + patientPhone + ') and email (' + patientEmail + ') within 60 minutes.<br>' +
              '<small style="display:inline-block; margin-top:6px; opacity:0.85;">Interactive Preview Note: This request was validated using the sample weekly schedule. In production, this form connects to your clinical calendar API for live atomic bookings.</small>' +
            '</p>';

          successCard.style.display = 'block';
          successCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 650);
    });

    // L. Initial State Setup
    updateTimeFieldState();
    updatePopoverHeader();
    renderSlots();
  }
  const contactForm = document.getElementById('spContactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const submitBtn = this.querySelector('button[type="submit"]');
      const origText = submitBtn ? submitBtn.innerHTML : 'Submit';
      if (submitBtn) {
        submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Encrypting &amp; Sending...';
        submitBtn.disabled = true;
      }
      setTimeout(() => {
        alert('Preview only. Your details stayed in this browser.');
        contactForm.reset();
        if (submitBtn) {
          submitBtn.innerHTML = origText;
          submitBtn.disabled = false;
        }
      }, 900);
    });
  }

});

// Follow direct links into the resource directory and open the selected topic.
function showResourceTopic() {
  const panel = document.getElementById(location.hash.slice(1));
  if (panel && panel.matches('.ed-directory details')) panel.open = true;
}
window.addEventListener('hashchange', showResourceTopic);
showResourceTopic();
const enquiry = document.querySelector('#cfMessage');
const topic = new URLSearchParams(location.search).get('topic');
if (enquiry && topic && !enquiry.value) enquiry.value = 'I would like to ask about ' + topic + '.';
